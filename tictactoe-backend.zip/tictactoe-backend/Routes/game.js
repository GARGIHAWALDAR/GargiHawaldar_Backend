const express = require('express');
const Game = require('C:/Users/Sumeet/Desktop/Tic-tac-toe/tictactoe-backend/models/Game.js');
const User = require('C:/Users/Sumeet/Desktop/Tic-tac-toe/tictactoe-backend/models/User.js');
const jwt = require('jsonwebtoken');

const router = express.Router();

// Middleware for authentication
const authenticate = (req, res, next) => {
    const token = req.header('Authorization');
    if (!token) return res.status(401).json({ error: 'Unauthorized' });

    try {
        const decoded = jwt.verify(token, 'your_jwt_secret_key');
        req.userId = decoded.userId;
        next();
    } catch {
        res.status(401).json({ error: 'Invalid token' });
    }
};

// Start a new game
router.post('/start', authenticate, async (req, res) => {
    const { opponentId } = req.body;

    try {
        const newGame = new Game({
            players: [req.userId, opponentId],
        });
        await newGame.save();
        res.status(201).json({ gameId: newGame._id });
    } catch (err) {
        res.status(500).json({ error: 'Error starting game' });
    }
});

// Make a move
router.post('/:gameId/move', authenticate, async (req, res) => {
    const { gameId } = req.params;
    const { position } = req.body;

    try {
        const game = await Game.findById(gameId).populate('players');
        if (game.status !== 'ongoing') return res.status(400).json({ error: 'Game is already completed' });

        const playerIndex = game.players.findIndex(player => player._id.toString() === req.userId);
        if (playerIndex !== game.currentTurn) return res.status(403).json({ error: 'Not your turn' });

        if (game.board[position] !== null) return res.status(400).json({ error: 'Invalid move' });

        game.board[position] = playerIndex === 0 ? 'X' : 'O';
        game.moves.push({ player: req.userId, position });
        game.currentTurn = 1 - game.currentTurn;

        // Check for winner or draw
        const winningCombinations = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6],
            [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6],
        ];

        for (const combo of winningCombinations) {
            const [a, b, c] = combo;
            if (game.board[a] && game.board[a] === game.board[b] && game.board[a] === game.board[c]) {
                game.status = 'completed';
                game.winner = game.board[a];
                break;
            }
        }

        if (!game.board.includes(null) && game.status !== 'completed') {
            game.status = 'completed';
            game.winner = null; // Draw
        }

        await game.save();
        res.json({ board: game.board, status: game.status, winner: game.winner });
    } catch (err) {
        res.status(500).json({ error: 'Error making move' });
    }
});

// Get match history
router.get('/history', authenticate, async (req, res) => {
    try {
        const games = await Game.find({ players: req.userId }).populate('players');
        const history = games.map(game => ({
            opponents: game.players.map(player => player.username).filter(name => name !== req.username),
            result: game.winner ? (game.winner === 'X' ? 'Win' : 'Loss') : 'Draw',
            moves: game.moves,
        }));
        res.json(history);
    } catch (err) {
        res.status(500).json({ error: 'Error fetching history' });
    }
});

module.exports = router;
