const mongoose = require('mongoose');

const GameSchema = new mongoose.Schema({
    players: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    board: { type: [String], default: Array(9).fill(null) },
    currentTurn: { type: Number, default: 0 }, // Index of the current player in `players`
    status: { type: String, enum: ['ongoing', 'completed'], default: 'ongoing' },
    winner: { type: String, default: null }, // 'X', 'O', or null for a draw
    moves: [
        {
            player: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
            position: Number,
        },
    ],
});

module.exports = mongoose.model('Game', GameSchema);
