const express = require('express');
const bodyParser = require('body-parser');
const { connectDB, closeDB } = require('C:/Users/Sumeet/Desktop/Tic-tac-toe/tictactoe-backend/config/db.js');
const authRoutes = require('C:/Users/Sumeet/Desktop/Tic-tac-toe/tictactoe-backend/Routes/auth.js');
const gameRoutes = require('C:/Users/Sumeet/Desktop/Tic-tac-toe/tictactoe-backend/Routes/game.js');

const app = express();

// Connect to in-memory MongoDB
connectDB();

app.use(bodyParser.json());
app.use('/api/auth', authRoutes);
app.use('/api/game', gameRoutes);

const PORT = 5000;
const server = app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

// Graceful shutdown
process.on('SIGINT', async () => {
    console.log('Shutting down server...');
    await closeDB();
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
});
